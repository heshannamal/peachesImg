Each product folder contains untouched original photos in Originals and one generated white-background image in Generated.
